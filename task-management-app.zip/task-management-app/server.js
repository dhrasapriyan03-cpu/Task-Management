require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database("tasks.db");
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "development_secret_change_me";

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',
    priority TEXT NOT NULL DEFAULT 'medium',
    due_date TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

function createToken(user) {
  return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
}
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return res.status(401).json({ message: "Please sign in first." });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ message: "Your session expired. Please sign in again." });
  }
}

app.post("/api/auth/register", (req, res) => {
  const { name, email, password } = req.body;
  if (!name?.trim() || !email?.trim() || !password || password.length < 6)
    return res.status(400).json({ message: "Enter your name, a valid email and a password of at least 6 characters." });
  try {
    const result = db.prepare("INSERT INTO users (name,email,password) VALUES (?,?,?)")
      .run(name.trim(), email.trim().toLowerCase(), bcrypt.hashSync(password, 10));
    const user = { id: result.lastInsertRowid, name: name.trim(), email: email.trim().toLowerCase() };
    res.status(201).json({ token: createToken(user), user });
  } catch {
    res.status(409).json({ message: "An account with that email already exists." });
  }
});

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get((email || "").toLowerCase());
  if (!user || !bcrypt.compareSync(password || "", user.password))
    return res.status(401).json({ message: "Incorrect email or password." });
  res.json({ token: createToken(user), user: { id: user.id, name: user.name, email: user.email } });
});

app.get("/api/tasks", auth, (req, res) => {
  const tasks = db.prepare("SELECT * FROM tasks WHERE user_id = ? ORDER BY created_at DESC, id DESC").all(req.user.id);
  res.json(tasks);
});

app.post("/api/tasks", auth, (req, res) => {
  const { title, description = "", priority = "medium", due_date = "" } = req.body;
  if (!title?.trim()) return res.status(400).json({ message: "Task title is required." });
  if (!["low", "medium", "high"].includes(priority)) return res.status(400).json({ message: "Invalid priority." });
  const result = db.prepare(
    "INSERT INTO tasks (user_id,title,description,priority,due_date) VALUES (?,?,?,?,?)"
  ).run(req.user.id, title.trim(), description, priority, due_date);
  res.status(201).json(db.prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?").get(result.lastInsertRowid, req.user.id));
});

app.put("/api/tasks/:id", auth, (req, res) => {
  const existing = db.prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id);
  if (!existing) return res.status(404).json({ message: "Task not found." });
  const title = (req.body.title ?? existing.title).trim();
  const description = req.body.description ?? existing.description;
  const status = req.body.status ?? existing.status;
  const priority = req.body.priority ?? existing.priority;
  const due_date = req.body.due_date ?? existing.due_date;
  if (!title) return res.status(400).json({ message: "Task title is required." });
  if (!["pending", "in-progress", "completed"].includes(status) || !["low", "medium", "high"].includes(priority))
    return res.status(400).json({ message: "Invalid task status or priority." });
  db.prepare("UPDATE tasks SET title=?,description=?,status=?,priority=?,due_date=? WHERE id=? AND user_id=?")
    .run(title, description, status, priority, due_date, req.params.id, req.user.id);
  res.json(db.prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id));
});

app.delete("/api/tasks/:id", auth, (req, res) => {
  const result = db.prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?").run(req.params.id, req.user.id);
  if (!result.changes) return res.status(404).json({ message: "Task not found." });
  res.json({ message: "Task deleted." });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Task Manager running at http://localhost:${PORT}`));
