const API = "/api";
let token = localStorage.getItem("taskflow_token") || "";
let currentUser = JSON.parse(localStorage.getItem("taskflow_user") || "null");
let tasks = [];
let filter = "all";
let editingId = null;
let registerMode = false;

const $ = id => document.getElementById(id);
const authView = $("authView"), appView = $("appView");
function headers() { return { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) }; }
async function request(url, options = {}) {
  const response = await fetch(API + url, { ...options, headers: { ...headers(), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401 && token) logout(false);
    throw new Error(data.message || "Something went wrong.");
  }
  return data;
}
function showMessage(id, message) { $(id).textContent = message; }
function showToast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2400);
}
function showAuth() { authView.classList.remove("hidden"); appView.classList.add("hidden"); }
function showApp() {
  authView.classList.add("hidden"); appView.classList.remove("hidden");
  $("userName").textContent = currentUser.name; $("userEmail").textContent = currentUser.email;
  $("avatar").textContent = currentUser.name.charAt(0).toUpperCase();
  $("greeting").textContent = `Let's make today count, ${currentUser.name.split(" ")[0]}.`;
  $("dateChip").textContent = new Date().toLocaleDateString(undefined, { weekday:"short", month:"short", day:"numeric" });
  $("todayLabel").textContent = new Date().toLocaleDateString(undefined, { weekday:"long", month:"long", year:"numeric" }).toUpperCase();
  loadTasks();
}
function logout(show = true) {
  token = ""; currentUser = null; tasks = [];
  localStorage.removeItem("taskflow_token"); localStorage.removeItem("taskflow_user");
  showAuth();
  if (show) showToast("You have signed out.");
}
function updateAuthMode() {
  $("nameLabel").classList.toggle("hidden", !registerMode);
  $("name").required = registerMode;
  $("authTitle").textContent = registerMode ? "Create your account." : "Welcome back.";
  $("authSubtitle").textContent = registerMode ? "Set up your workspace in a few seconds." : "Sign in to pick up where you left off.";
  $("authSubmit").textContent = registerMode ? "Create account" : "Sign in";
  $("authSwitch").innerHTML = registerMode ? 'Already have an account? <button class="link-btn" id="switchAuth" type="button">Sign in</button>' : 'New to TaskFlow? <button class="link-btn" id="switchAuth" type="button">Create an account</button>';
  $("switchAuth").addEventListener("click", () => { registerMode = !registerMode; updateAuthMode(); showMessage("authMessage", ""); });
}
$("switchAuth").addEventListener("click", () => { registerMode = !registerMode; updateAuthMode(); });
$("authForm").addEventListener("submit", async e => {
  e.preventDefault(); showMessage("authMessage", "");
  const body = { email: $("email").value, password: $("password").value };
  if (registerMode) body.name = $("name").value;
  try {
    const data = await request(registerMode ? "/auth/register" : "/auth/login", { method:"POST", body:JSON.stringify(body) });
    token = data.token; currentUser = data.user;
    localStorage.setItem("taskflow_token", token); localStorage.setItem("taskflow_user", JSON.stringify(currentUser));
    showApp();
  } catch (err) { showMessage("authMessage", err.message); }
});
$("logout").addEventListener("click", () => logout());

async function loadTasks() {
  try { tasks = await request("/tasks"); render(); }
  catch (err) { showToast(err.message); }
}
function render() {
  $("totalStat").textContent = tasks.length;
  $("progressStat").textContent = tasks.filter(t => t.status === "in-progress").length;
  $("completedStat").textContent = tasks.filter(t => t.status === "completed").length;
  $("allCount").textContent = tasks.length;
  const query = $("searchInput").value.toLowerCase();
  let visible = tasks.filter(t => (filter === "all" || t.status === filter) &&
    (t.title.toLowerCase().includes(query) || (t.description || "").toLowerCase().includes(query)));
  const sort = $("sortSelect").value;
  if (sort === "due") visible.sort((a,b) => (a.due_date || "9999").localeCompare(b.due_date || "9999"));
  if (sort === "priority") visible.sort((a,b) => ["high","medium","low"].indexOf(a.priority) - ["high","medium","low"].indexOf(b.priority));
  $("taskList").innerHTML = "";
  $("emptyState").classList.toggle("hidden", visible.length > 0);
  $("taskList").classList.toggle("hidden", visible.length === 0);
  visible.forEach(task => {
    const card = document.createElement("article");
    card.className = "task-card" + (task.status === "completed" ? " done" : "");
    const check = document.createElement("input"); check.type = "checkbox"; check.className = "task-check";
    check.checked = task.status === "completed"; check.setAttribute("aria-label", "Mark task completed");
    check.addEventListener("change", () => updateTask(task.id, { status: check.checked ? "completed" : "pending" }));
    const info = document.createElement("div"); info.className = "task-info";
    const title = document.createElement("p"); title.className = "task-title"; title.textContent = task.title;
    const desc = document.createElement("p"); desc.className = "task-desc"; desc.textContent = task.description || "";
    const meta = document.createElement("div"); meta.className = "task-meta";
    const priority = document.createElement("span"); priority.className = `pill priority-${task.priority}`; priority.textContent = `${task.priority} priority`;
    const status = document.createElement("span"); status.className = `pill status-${task.status}`; status.textContent = task.status === "in-progress" ? "In progress" : task.status === "completed" ? "Completed" : "To do";
    meta.append(priority, status);
    if (task.due_date) { const due = document.createElement("span"); due.className = "due"; due.textContent = `Due ${new Date(task.due_date + "T00:00:00").toLocaleDateString()}`; meta.append(due); }
    info.append(title, desc, meta);
    const actions = document.createElement("div"); actions.className = "task-actions";
    const edit = document.createElement("button"); edit.textContent = "✎"; edit.title = "Edit task"; edit.addEventListener("click", () => openModal(task));
    const del = document.createElement("button"); del.textContent = "⌫"; del.title = "Delete task"; del.addEventListener("click", () => deleteTask(task.id));
    actions.append(edit, del); card.append(check, info, actions); $("taskList").append(card);
  });
}
document.querySelectorAll(".nav-item").forEach(btn => btn.addEventListener("click", () => {
  filter = btn.dataset.filter;
  document.querySelectorAll(".nav-item").forEach(x => x.classList.toggle("active", x === btn));
  $("pageTitle").textContent = ({all:"All tasks",pending:"To do", "in-progress":"In progress",completed:"Completed"})[filter];
  render();
}));
$("searchInput").addEventListener("input", render);
$("sortSelect").addEventListener("change", render);

function openModal(task = null) {
  editingId = task ? task.id : null;
  $("modalTitle").textContent = task ? "Edit task" : "Create a task";
  $("taskTitle").value = task?.title || "";
  $("taskDescription").value = task?.description || "";
  $("taskPriority").value = task?.priority || "medium";
  $("taskDue").value = task?.due_date || "";
  $("taskStatus").value = task?.status || "pending";
  $("statusLabel").classList.toggle("hidden", !task);
  $("taskMessage").textContent = "";
  $("taskModal").classList.remove("hidden");
  $("taskTitle").focus();
}
function closeModal() { $("taskModal").classList.add("hidden"); }
$("addTaskBtn").addEventListener("click", () => openModal());
$("emptyAdd").addEventListener("click", () => openModal());
$("closeModal").addEventListener("click", closeModal);
$("cancelModal").addEventListener("click", closeModal);
$("taskModal").addEventListener("click", e => { if (e.target === $("taskModal")) closeModal(); });
$("taskForm").addEventListener("submit", async e => {
  e.preventDefault();
  const body = { title:$("taskTitle").value, description:$("taskDescription").value, priority:$("taskPriority").value, due_date:$("taskDue").value, status:$("taskStatus").value };
  try {
    if (editingId) await request(`/tasks/${editingId}`, { method:"PUT", body:JSON.stringify(body) });
    else await request("/tasks", { method:"POST", body:JSON.stringify(body) });
    closeModal(); await loadTasks(); showToast(editingId ? "Task updated." : "Task created.");
  } catch (err) { showMessage("taskMessage", err.message); }
});
async function updateTask(id, changes) {
  const task = tasks.find(t => t.id === id);
  try { await request(`/tasks/${id}`, { method:"PUT", body:JSON.stringify({ ...task, ...changes }) }); await loadTasks(); }
  catch (err) { showToast(err.message); }
}
async function deleteTask(id) {
  if (!confirm("Delete this task? This cannot be undone.")) return;
  try { await request(`/tasks/${id}`, { method:"DELETE" }); await loadTasks(); showToast("Task deleted."); }
  catch (err) { showToast(err.message); }
}
if (token && currentUser) showApp(); else showAuth();
