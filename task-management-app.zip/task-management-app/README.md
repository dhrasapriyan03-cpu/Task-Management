# TaskFlow — Task Management Application

A responsive full-stack task manager built with HTML, CSS, JavaScript, Node.js, Express and SQLite.

## Features
- User registration and login with hashed passwords
- JWT authentication and per-user task authorization
- Create, view, edit, complete and delete tasks (CRUD)
- Task priority, due date and status tracking
- Search and sort tasks
- Responsive desktop and mobile layout
- SQLite database created automatically on first run

## Requirements
- Node.js 18 or newer
- npm

## Run locally
1. Extract the ZIP and open the project folder in a terminal.
2. Install packages:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env`.
4. Change `JWT_SECRET` in `.env` to a long random secret.
5. Start the application:
   ```bash
   npm start
   ```
6. Open http://localhost:3000

The SQLite database (`tasks.db`) is created automatically in the project folder.

## API endpoints

| Method | Endpoint | Purpose | Auth |
|---|---|---|---|
| POST | `/api/auth/register` | Create account | No |
| POST | `/api/auth/login` | Sign in | No |
| GET | `/api/tasks` | List signed-in user's tasks | Yes |
| POST | `/api/tasks` | Create task | Yes |
| PUT | `/api/tasks/:id` | Update task | Yes |
| DELETE | `/api/tasks/:id` | Delete task | Yes |

For protected endpoints, send `Authorization: Bearer <token>`.

## Project structure
```text
task-management-app/
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── server.js
├── package.json
├── .env.example
├── .gitignore
└── README.md
```

## Notes
- Passwords are hashed with bcrypt before storage.
- Each task query is scoped to the authenticated user's ID.
- This is a learning project. Before public production deployment, add HTTPS, rate limiting, stronger validation, secure cookie-based token storage, database backups and deployment-specific secrets.
- Real-time WebSocket updates are optional and are not included in this version.
